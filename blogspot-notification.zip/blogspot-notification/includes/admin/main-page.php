<?php
global $wpdb;

$subscribers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}bn_subscribers");

if (!empty($subscribers)) {
    echo '<h2>Subscribers List</h2>';
    echo '<table><thead><tr><th>Name</th><th>Email</th></thead><tbody>';
    foreach ($subscribers as $subscriber) {
        echo '<tr><td>' . esc_html($subscriber->name) . '</td><td>' . esc_html($subscriber->email) . '</td></tr>';
    }
    echo '</tbody></table>';
} else {
    echo '<p>No subscribers found.</p>';
}

echo '<h2>Statistics</h2>';
echo '<p>Total Subscribers: ' . esc_html($total_subscribers) . '</p>';
echo '<p>Opened Emails: ' . esc_html($opened_emails) . '</p>';
?>

<h2>Add Subscriber</h2>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
    <input type="hidden" name="action" value="bn_add_subscriber">
    <?php wp_nonce_field('bn_add_subscriber'); ?>
    <p><label>Name: <input type="text" name="name"></label></p>
    <p><label>Email: <input type="email" name="email"></label></p>
    <p><input type="submit" value="Add Subscriber"></p>
</form>

<h2>Import Subscribers from CSV</h2>
<form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
    <input type="hidden" name="action" value="bn_import_subscribers">
    <?php wp_nonce_field('bn_import_subscribers'); ?>
    <p><label>CSV File: <input type="file" name="csv_file"></label></p>
    <p><input type="submit" value="Import Subscribers"></p>
</form>