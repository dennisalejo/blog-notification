<?php
function bn_subscribe_form_shortcode() {
    ob_start();
    ?>
    <form id="bn-subscribe-form" method="post" action="">
        <label for="bn-name">Name</label>
        <input type="text" id="bn-name" name="bn_name" required>
        <label for="bn-email">Email</label>
        <input type="email" id="bn-email" name="bn_email" required>
        <button type="submit">Subscribe</button>
        <?php wp_nonce_field('bn_subscribe_form', 'bn_subscribe_nonce'); ?>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('bn_subscribe_form', 'bn_subscribe_form_shortcode');

function bn_handle_form_submit() {
    if (isset($_POST['bn_subscribe_nonce']) && wp_verify_nonce($_POST['bn_subscribe_nonce'], 'bn_subscribe_form')) {
        if (!empty($_POST['bn_name']) && !empty($_POST['bn_email'])) {
            global $wpdb;
            $name = sanitize_text_field($_POST['bn_name']);
            $email = sanitize_email($_POST['bn_email']);
            $wpdb->insert("{$wpdb->prefix}bn_subscribers", array('name' => $name, 'email' => $email));
        }
    }
}
add_action('init', 'bn_handle_form_submit');
?>