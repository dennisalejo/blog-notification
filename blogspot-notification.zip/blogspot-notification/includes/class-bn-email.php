<?php
class BN_Email {

    public function __construct() {
        add_action('publish_post', array($this, 'bn_notify_subscribers'), 10, 2);
    }

    public function bn_notify_subscribers($ID, $post) {
        global $wpdb;
        $subscribers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}bn_subscribers");

        foreach ($subscribers as $subscriber) {
            $to = $subscriber->email;
            $subject = 'New Blog Post: ' . $post->post_title;
            $message = '<h1>' . $post->post_title . '</h1>';
            $message .= get_the_post_thumbnail($ID, 'thumbnail');
            $message .= '<p>' . wp_trim_words($post->post_content, 30) . '</p>';
            $message .= '<a href="' . get_permalink($ID) . '">Read More</a>';
            $message .= '<p><a href="' . site_url('/?bn_unsubscribe=' . $subscriber->id) . '">Unsubscribe</a> | <a href="' . site_url('/?bn_update=' . $subscriber->id) . '">Update Subscription</a></p>';
            $message .= '<div style="background: #87CEEB; padding: 10px; text-align: center; margin-top: 20px;">';
            $message .= 'Powered by: <a href="https://dennis.tips" style="color: #ffffff;">Blogspot Notification</a>';
            $message .= '</div>';

            // SMTP settings handled by WP Mail SMTP
            wp_mail($to, $subject, $message, array('Content-Type: text/html; charset=UTF-8'));
        }
    }
}
?>