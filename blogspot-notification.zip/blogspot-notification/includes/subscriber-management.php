<?php
// Handle subscriber management, add subscribers, import CSV, etc.

function blogspot_notification_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Create subscribers table
    $subs_table = $wpdb->prefix . 'blogspot_subscribers';
    $subs_sql = "CREATE TABLE $subs_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name tinytext NOT NULL,
        email varchar(100) NOT NULL,
        subscribed datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // Create opens tracking table
    $opens_table = $wpdb->prefix . 'blogspot_opens';
    $opens_sql = "CREATE TABLE $opens_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        subscriber_id mediumint(9) NOT NULL,
        post_id mediumint(9) NOT NULL,
        opened datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // Create clicks tracking table
    $clicks_table = $wpdb->prefix . 'blogspot_clicks';
    $clicks_sql = "CREATE TABLE $clicks_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        subscriber_id mediumint(9) NOT NULL,
        post_id mediumint(9) NOT NULL,
        clicked datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($subs_sql);
    dbDelta($opens_sql);
    dbDelta($clicks_sql);
}

register_activation_hook(__FILE__, 'blogspot_notification_create_tables');

function blogspot_add_subscriber($name, $email) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'blogspot_subscribers';

    $wpdb->insert(
        $table_name,
        [
            'name' => sanitize_text_field($name),
            'email' => sanitize_email($email),
            'subscribed' => current_time('mysql')
        ]
    );
}
?>