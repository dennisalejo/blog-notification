<?php
// Track email opens

function blogspot_track_opens() {
    if (isset($_GET['subscriber_id']) && isset($_GET['post_id'])) {
        global $wpdb;

        $subscriber_id = intval($_GET['subscriber_id']);
        $post_id = intval($_GET['post_id']);
        $table_name = $wpdb->prefix . 'blogspot_opens';

        $wpdb->insert(
            $table_name,
            [
                'subscriber_id' => $subscriber_id,
                'post_id' => $post_id,
                'opened' => current_time('mysql')
            ]
        );

        header('Content-type: image/gif');
        echo base64_decode('R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=='); // 1x1 transparent gif
        exit;
    }
}

add_action('init', 'blogspot_track_opens');