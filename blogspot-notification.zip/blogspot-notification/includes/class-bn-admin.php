<?php
class BN_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'bn_admin_menu'));
        add_action('admin_post_bn_add_subscriber', array($this, 'bn_add_subscriber'));
        add_action('admin_post_bn_import_subscribers', array($this, 'bn_import_subscribers'));
    }

    public function bn_admin_menu() {
        add_menu_page('Blogspot Notification', 'Blogspot Notification', 'manage_options', 'blogspot-notification', array($this, 'bn_admin_page'));
    }

    public function bn_admin_page() {
        global $wpdb;
        $total_subscribers = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bn_subscribers");
        $opened_emails = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bn_email_opened"); // This assumes you have a way to track opened emails.

        include_once plugin_dir_path(__FILE__) . 'admin/main-page.php';
    }

    public function bn_add_subscriber() {
        // Handle form submission to add a subscriber.
        check_admin_referer('bn_add_subscriber');
        
        global $wpdb;
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        
        $wpdb->insert("{$wpdb->prefix}bn_subscribers", array('name' => $name, 'email' => $email));
        
        wp_redirect(admin_url('admin.php?page=blogspot-notification'));
        exit();
    }

    public function bn_import_subscribers() {
        // Handle CSV upload.
        check_admin_referer('bn_import_subscribers');

        $csv = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($csv, "r")) !== FALSE) {
            global $wpdb;
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $wpdb->insert("{$wpdb->prefix}bn_subscribers", array('name' => sanitize_text_field($data[0]), 'email' => sanitize_email($data[1])));
            }
            fclose($handle);
        }
        
        wp_redirect(admin_url('admin.php?page=blogspot-notification'));
        exit();
    }
}
?>