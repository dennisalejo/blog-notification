<?php
// Handle sending notification emails upon new post publication

function blogspot_send_notification($post_id) {
    // Ensure this function runs only once
    if (get_post_meta($post_id, '_sent_notification', true)) return;

    global $wpdb;
    $subscribers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}blogspot_subscribers");

    if ($subscribers) {
        $post = get_post($post_id);
        $permalink = get_permalink($post_id);
        $subject = 'New Post: ' . $post->post_title;
        $message = '<h1>' . $post->post_title . '</h1>';
        $message .= get_the_post_thumbnail($post_id, 'full');
        $message .= '<p>' . substr($post->post_content, 0, 100) . '...</p>';

        foreach ($subscribers as $subscriber) {
            $tracking_open_url = add_query_arg(['subscriber_id' => $subscriber->id, 'post_id' => $post_id], home_url('/wp-admin/admin-ajax.php?action=blogspot_track_open'));
            $tracking_click_url = add_query_arg([
                'subscriber_id' => $subscriber->id,
                'post_id' => $post_id,
                'redirect' => $permalink
            ], home_url('/wp-admin/admin-ajax.php?action=blogspot_track_click'));

            $email_message = $message;
            $email_message .= '<a href="' . $tracking_click_url . '">Read More</a>';
            $email_message .= '<img src="' . $tracking_open_url . '" width="1" height="1" alt="" style="display:none;" />';

            $headers = ['Content-Type: text/html; charset=UTF-8', 'From: ' . get_option('blogspot_notification_sender_email')];

            wp_mail($subscriber->email, $subject, $email_message, $headers);
        }

        // Mark as sent
        update_post_meta($post_id, '_sent_notification', 'yes');
    }
}

add_action('publish_post', 'blogspot_send_notification');