<?php
// Handle statistics, track email link clicks, etc.

function blogspot_statistics_page() {
    global $wpdb;

    $opens_table = $wpdb->prefix . 'blogspot_opens';
    $clicks_table = $wpdb->prefix . 'blogspot_clicks';

    $total_opens = $wpdb->get_var("SELECT COUNT(*) FROM {$opens_table}");
    $total_clicks = $wpdb->get_var("SELECT COUNT(*) FROM {$clicks_table}");
    ?>
    <div class="wrap">
        <h1>Statistics</h1>
        <table class="form-table">
            <tr>
                <th>Total Opens</th>
                <td><?php echo esc_html($total_opens); ?></td>
            </tr>
            <tr>
                <th>Total Clicks</th>
                <td><?php echo esc_html($total_clicks); ?></td>
            </tr>
        </table>

        <h2>Open Details</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Subscriber</th>
                    <th>Post</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $open_details = $wpdb->get_results("SELECT * FROM {$opens_table}");
                foreach ($open_details as $open) {
                    $subscriber = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}blogspot_subscribers WHERE id = %d", $open->subscriber_id));
                    $post = get_post($open->post_id);
                    echo '<tr>';
                    echo '<td>' . esc_html($subscriber->name) . ' (' . esc_html($subscriber->email) . ')</td>';
                    echo '<td>' . esc_html($post->post_title) . '</td>';
                    echo '<td>' . esc_html($open->opened) . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>

        <h2>Click Details</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Subscriber</th>
                    <th>Post</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $click_details = $wpdb->get_results("SELECT * FROM {$clicks_table}");
                foreach ($click_details as $click) {
                    $subscriber = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}blogspot_subscribers WHERE id = %d", $click->subscriber_id));
                    $post = get_post($click->post_id);
                    echo '<tr>';
                    echo '<td>' . esc_html($subscriber->name) . ' (' . esc_html($subscriber->email) . ')</td>';
                    echo '<td>' . esc_html($post->post_title) . '</td>';
                    echo '<td>' . esc_html($click->clicked) . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Add stats page to backend
function blogspot_statistics_menu() {
    add_submenu_page('blogspot-notification', 'Statistics', 'Statistics', 'manage_options', 'blogspot-statistics', 'blogspot_statistics_page');
}
add_action('admin_menu', 'blogspot_statistics_menu');
?>