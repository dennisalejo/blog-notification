<?php
// Track link clicks

function blogspot_track_clicks() {
    if (isset($_GET['subscriber_id']) && isset($_GET['post_id']) && isset($_GET['redirect'])) {
        global $wpdb;

        $subscriber_id = intval($_GET['subscriber_id']);
        $post_id = intval($_GET['post_id']);
        $redirect_url = esc_url_raw($_GET['redirect']);
        $table_name = $wpdb->prefix . 'blogspot_clicks';

        $wpdb->insert(
            $table_name,
            [
                'subscriber_id' => $subscriber_id,
                'post_id' => $post_id,
                'clicked' => current_time('mysql')
            ]
        );

        wp_redirect($redirect_url);
        exit;
    }
}

add_action('init', 'blogspot_track_clicks');