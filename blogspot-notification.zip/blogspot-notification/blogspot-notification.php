<?php
/**
 * Plugin Name: Blogspot Notification
 * Plugin URI: https://instantwebtools.co
 * Description: Blogspot Notification automates notifications from blog posts to a newsletter format.
 * Version: 1.0
 * Author: Dennis Alejo
 * Author URI: https://dennis.tips
 */

if (!defined('ABSPATH')) {
    exit;
}

// Include necessary files.
include_once plugin_dir_path(__FILE__) . 'includes/class-bn-admin.php';
include_once plugin_dir_path(__FILE__) . 'includes/class-bn-email.php';
include_once plugin_dir_path(__FILE__) . 'includes/shortcode/subscribe_form.php';

// Activation hook to create database tables.
register_activation_hook(__FILE__, 'bn_activate_plugin');

function bn_activate_plugin() {
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    global $wpdb;

    $table_name = $wpdb->prefix . 'bn_subscribers';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name tinytext NOT NULL,
        email text NOT NULL,
        UNIQUE KEY id (id)
    ) $charset_collate;";

    dbDelta($sql);
}

// Load the plugin.
add_action('plugins_loaded', 'bn_init_plugin');

function bn_init_plugin() {
    // Initialize admin settings.
    if (is_admin()) {
        new BN_Admin();
    }

    // Initialize email notifications.
    new BN_Email();
}
?>