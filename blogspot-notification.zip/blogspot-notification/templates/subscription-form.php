<?php
global $wpdb;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'], $_POST['email'])) {
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    
    $table_name = $wpdb->prefix . 'blogspot_subscribers';

    $wpdb->insert(
        $table_name,
        [
            'name' => $name,
            'email' => $email,
            'subscribed' => current_time('mysql')
        ]
    );

    echo '<p>Thank you for subscribing!</p>';
}
?>

<form method="post" id="blogspot_notification_form">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" required>
    <label for="email">Email</label>
    <input type="email" name="email" id="email" required>
    <button type="submit">Subscribe</button>
</form>