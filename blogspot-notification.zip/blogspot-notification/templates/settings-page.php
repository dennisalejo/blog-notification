<div class="wrap">
    <h1>Blogspot Notification Settings</h1>
    <form method="post" action="options.php">
        <?php settings_fields('blogspot_notification_settings'); ?>
        <?php do_settings_sections('blogspot_notification_settings'); ?>
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Sender Email</th>
                <td><input type="email" name="blogspot_notification_sender_email" value="<?php echo esc_attr(get_option('blogspot_notification_sender_email')); ?>" required/></td>
            </tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>