<div class="wrap">
    <h1>Subscribers</h1>
    <form method="post" enctype="multipart/form-data">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Name</th>
                <td><input type="text" name="subscriber_name" required/></td>
            </tr>
            <tr valign="top">
                <th scope="row">Email</th>
                <td><input type="email" name="subscriber_email" required/></td>
            </tr>
        </table>
        <?php submit_button('Add Subscriber'); ?>
    </form>

    <h2>Upload CSV</h2>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="csv_file" accept=".csv" required/>
        <?php submit_button('Upload'); ?>
    </form>

    <h2>Subscribers List</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Date Subscribed</th>
            </tr>
        </thead>
        <tbody>
            <?php
            global $wpdb;
            $table_name = $wpdb->prefix . 'blogspot_subscribers';
            $subscribers = $wpdb->get_results("SELECT * FROM {$table_name}");
            if ($subscribers) {
                foreach ($subscribers as $subscriber) {
                    echo '<tr>';
                    echo '<td>' . esc_html($subscriber->name) . '</td>';
                    echo '<td>' . esc_html($subscriber->email) . '</td>';
                    echo '<td>' . esc_html($subscriber->subscribed) . '</td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="3">No subscribers found.</td></tr>';
            }
            ?>
        </tbody>
    </table>
</div>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['subscriber_name']) && !empty($_POST['subscriber_email'])) {
    blogspot_add_subscriber($_POST['subscriber_name'], $_POST['subscriber_email']);
    echo '<p>Subscriber added successfully!</p>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];
    $handle = fopen($file, 'r');

    while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
        if (filter_var($data[1], FILTER_VALIDATE_EMAIL)) {
            blogspot_add_subscriber($data[0], $data[1]);
        }
    }

    fclose($handle);
    echo '<p>CSV uploaded and subscribers added successfully!</p>';
}
?>