// Optional JavaScript for enhanced interactions (if needed)
jQuery(document).ready(function($) {
    // Add any custom JavaScript code here
});